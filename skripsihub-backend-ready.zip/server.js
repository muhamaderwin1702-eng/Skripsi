const express = require("express");
const path = require("path");
const rateLimit = require("express-rate-limit");
const sanitizeHtml = require("sanitize-html");

const app = express();
const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { success: false, error: "Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi." }
});
app.use("/api/", apiLimiter);

app.get("/api/health", (_req, res) => {
  res.json({
    success: true,
    service: "SkripsiHub backend",
    apiKeyConfigured: Boolean(GEMINI_API_KEY)
  });
});

async function askGemini(prompt, maxOutputTokens = 6000) {
  if (!GEMINI_API_KEY) {
    const error = new Error("API Key Gemini belum dipasang pada Environment Variables server.");
    error.status = 503;
    throw error;
  }

  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": GEMINI_API_KEY
    },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.65,
        maxOutputTokens
      }
    })
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = payload?.error?.message || `Gemini API mengembalikan status ${response.status}`;
    const error = new Error(message);
    error.status = response.status === 429 ? 429 : 502;
    throw error;
  }

  const output = (payload.candidates?.[0]?.content?.parts || [])
    .map(part => part.text || "")
    .join("\n")
    .trim();

  if (!output) {
    const error = new Error("Gemini tidak mengembalikan teks. Coba lagi dengan instruksi yang lebih singkat.");
    error.status = 502;
    throw error;
  }
  return output;
}

app.post("/api/generate-bab", async (req, res) => {
  try {
    const { bab, project } = req.body || {};
    const babNumber = Number(bab);
    if (![1, 2, 3, 4, 5].includes(babNumber) || !project || typeof project !== "object") {
      return res.status(400).json({ success: false, error: "Data Bab atau parameter penelitian tidak lengkap." });
    }

    const prompt = `
Anda adalah asisten akademik berbahasa Indonesia. Bantu menyusun DRAF akademik untuk ditinjau dan diperbaiki mahasiswa bersama dosen pembimbing. Jangan mengarang data penelitian, hasil wawancara, angka statistik, kutipan, DOI, atau sumber.
Informasi penelitian:
Judul: ${String(project.judul || "").slice(0, 1500)}
Jenis karya: ${String(project.jenis || "Skripsi").slice(0, 100)}
Metode: ${String(project.metode || "").slice(0, 100)}
Program studi/kampus: ${String(project.prodi || "").slice(0, 300)}
Catatan/data nyata dari pengguna: ${String(project.dataReal || "").slice(0, 5000)}
Bab yang diminta: BAB ${babNumber}

Tugas:
- Susun draf BAB ${babNumber} yang runtut, jelas, relevan dengan judul, metode, dan bidang studi.
- Gunakan subjudul yang sesuai dengan struktur umum karya ilmiah Indonesia.
- Jika informasi penting belum tersedia, tandai secara jelas dengan [PERLU DILENGKAPI: ...], jangan menebak.
- Jangan membuat referensi palsu. Jika menyebut teori atau penelitian terdahulu yang sumbernya belum dapat dipastikan, beri tanda [SUMBER AKADEMIK PERLU DIVERIFIKASI].
- Untuk BAB IV dan V, jangan membuat hasil atau kesimpulan empiris tanpa data nyata yang diberikan pengguna.
- Keluaran hanya berupa fragmen HTML sederhana yang aman untuk ditampilkan di elemen halaman: gunakan h2, h3, p, ul, ol, li, strong, em, blockquote. Jangan gunakan tag html, head, body, script, style, atau markdown fence.
- Berikan draf yang cukup terperinci, tetapi jangan mengulang isi untuk memanjangkan tulisan.
`;
    const raw = await askGemini(prompt, 7000);
    const content = sanitizeHtml(raw, {
      allowedTags: ["h2", "h3", "h4", "p", "ul", "ol", "li", "strong", "em", "blockquote", "br"],
      allowedAttributes: {}
    });
    return res.json({ success: true, content });
  } catch (error) {
    console.error("generate-bab:", error.message);
    return res.status(error.status || 500).json({ success: false, error: error.message || "Terjadi kesalahan server." });
  }
});

app.post("/api/brainstorm", async (req, res) => {
  try {
    const topik = String(req.body?.topik || "").trim();
    if (!topik) return res.status(400).json({ error: "Topik penelitian wajib diisi." });
    if (topik.length > 1000) return res.status(400).json({ error: "Topik terlalu panjang." });

    const prompt = `
Buat tepat 10 alternatif judul penelitian skripsi berbahasa Indonesia berdasarkan topik berikut:
"${topik}"
Judul harus spesifik, masuk akal, tidak menjanjikan hasil, dan sesuai kaidah penelitian.
Kembalikan HANYA JSON array berisi 10 string judul. Jangan tambahkan markdown atau penjelasan.
`;
    const raw = await askGemini(prompt, 1800);
    let titles;
    try {
      const cleaned = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed)) titles = parsed.filter(x => typeof x === "string").slice(0, 10);
    } catch (_) {
      titles = raw.split(/\r?\n/)
        .map(line => line.replace(/^\s*(?:[-*]|\d+[.)])\s*/, "").trim())
        .filter(Boolean)
        .slice(0, 10);
    }
    if (!titles?.length) throw new Error("AI belum menghasilkan daftar judul yang dapat dibaca.");
    return res.json({ titles });
  } catch (error) {
    console.error("brainstorm:", error.message);
    return res.status(error.status || 500).json({ error: error.message || "Terjadi kesalahan server." });
  }
});

// Jangan izinkan file konfigurasi/backend diunduh sebagai file statis.
app.use((req, res, next) => {
  if (["/server.js", "/package.json", "/.env", "/.env.example"].includes(req.path)) {
    return res.sendStatus(404);
  }
  next();
});
app.use(express.static(__dirname, { dotfiles: "deny", index: "index.html" }));

app.use((req, res, next) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ success: false, error: "Endpoint API tidak ditemukan." });
  res.sendFile(path.join(__dirname, "index.html"), err => err && next(err));
});

app.listen(PORT, () => {
  console.log(`SkripsiHub berjalan pada port ${PORT}`);
});

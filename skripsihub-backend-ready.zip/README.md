# SkripsiHub — paket frontend + backend

## Isi paket
- `index.html`: tampilan SkripsiHub yang sudah ada.
- `server.js`: backend Express dengan endpoint `/api/generate-bab` dan `/api/brainstorm`.
- `package.json`: daftar dependensi dan perintah menjalankan server.

## Deploy sebagai satu aplikasi di Render
1. Unggah isi folder ini ke repository GitHub (file `index.html`, `server.js`, `package.json`, `.gitignore`, `.env.example` harus berada di root repository, bukan ZIP).
2. Di Render buat **New > Web Service**, hubungkan repository tersebut.
3. Pilih runtime Node. Build Command: `npm install`. Start Command: `npm start`.
4. Di Environment Variables Render, tambahkan `GEMINI_API_KEY` dengan API key milikmu. Jangan masukkan API key ke GitHub atau ke `index.html`.
5. Deploy. Setelah selesai, buka URL Render. Gunakan URL Render sebagai alamat website utama.

## Pemeriksaan
Buka `https://ALAMAT-RENDER/api/health`. Respons `apiKeyConfigured: true` berarti server membaca API key.
Endpoint AI:
- `POST /api/generate-bab`
- `POST /api/brainstorm`

## Catatan penting
- GitHub Pages hanya hosting statis. Backend ini harus berjalan pada layanan Node.js seperti Render.
- Gemini API dapat memiliki batas penggunaan, kuota, atau biaya sesuai pengaturan akun Google AI Studio.
- Hasil AI adalah draf. Periksa fakta, sumber, sitasi, etika penelitian, dan pedoman kampus sebelum digunakan.
- Versi ini menghubungkan dua fitur yang memang dipanggil oleh HTML saat ini. Fitur lain yang hanya berupa tampilan/placeholder belum otomatis memiliki backend.
